﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Stark.Models;

namespace Stark.Controllers
{
    public class ReportsController : Controller
    {
        private readonly starkContext _context;

        public ReportsController(starkContext context)
        {
            _context = context;
        }
        public int Counter(string plate)
        {
            int counter;
            counter = _context.Review.Count(s => s.Licence.Plate == plate);
            return counter;
        }

        public double ScoreCounter(int id, int type, int weight=1)
        {
            double counter;
            counter = _context.Review.Count(s => s.Badge.Type == type && s.LicenceId == id);
            return counter*type*weight;
        }

        public double ScoreCounter(int id, int type, int weight, string title)
        {
            double counter;
            counter = _context.Review.Count(s => s.Badge.Type == type && s.LicenceId == id && s.Badge.Title==title);
            return counter*type*weight;
        }

        public IDictionary<string, double> GetScore()
        {
            IDictionary<string, double> scores = new Dictionary<string, double>();

            foreach (var item in _context.Cars)
            {
                scores.Add(item.Plate, (ScoreCounter(item.LicenceId, 0, 1) + ScoreCounter(item.LicenceId, 1, 1) + ScoreCounter(item.LicenceId, 3, 1) + ScoreCounter(item.LicenceId, 4, 1))/Counter(item.Plate));

            }
            return scores;
        }

        
        public int GetId(string plate)
        {
            int id;
            Cars ob = _context.Cars.Where(s=>s.Plate==plate).FirstOrDefault();
            id = ob.LicenceId;
            return id;
        }

        public IActionResult Index()
        {
            var ScoreList = GetScore().ToList();
            ScoreList.Sort((pair1, pair2) => pair2.Value.CompareTo(pair1.Value));
            List<CarsViewcs> All=new List<CarsViewcs>();
            int i = 1;
            foreach (var item in ScoreList)
            {
                CarsViewcs c = new CarsViewcs { LicenceId=GetId(item.Key), Position=i, Plate = item.Key, ReviewCount = Counter(item.Key), Score = item.Value };
                if (c.ReviewCount > 0)
                    {
                    All.Add(c);
                    ++i;
                }

            }
            return View(All);
        }
    }
}