﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


$('#0').click(function () {
    $("#Plate").val($("#0").val());
});
$('#1').click(function () {
    $("#Plate").val($("#1").val());
}); $('#2').click(function () {
    $("#Plate").val($("#2").val());
}); $('#3').click(function () {
    $("#Plate").val($("#3").val());
});

    